<?php get_template_part('partials/header'); ?>
<?php get_template_part('partials/preloader'); ?>
<?php get_template_part('partials/mp_color'); ?>
<?php get_template_part('partials/header_tag'); ?>
<?php get_template_part('partials/slider'); ?>
<?php get_template_part('partials/service'); ?>
<?php get_template_part('partials/about'); ?>
<?php get_template_part('partials/skill'); ?>
<?php get_template_part('partials/choose_us'); ?>
<?php get_template_part('partials/team'); ?>
<?php get_template_part('partials/testimonial'); ?>
<?php get_template_part('partials/portfolio'); ?>
<?php get_template_part('partials/static'); ?>
<?php get_template_part('partials/blog'); ?>
<?php get_template_part('partials/contact_us'); ?>
<?php get_template_part('partials/localisation'); ?>
<?php get_template_part('partials/newsletter'); ?>
<?php get_template_part('partials/client'); ?>
<?php get_template_part('partials/footer'); ?>


		
		
		


		
		
		
		
		
		
		
		
		
		
		
		
		
		
		