<!-- Why Choose Us -->
<div id="why-choose" class="section">
			<div class="why-image">
				<div class="video"><a href="https://www.youtube.com/watch?v=wZWiRoktNWA" class="video-play mfp-iframe wow zoomIn"><i class="fa fa-play"></i></a></div>
				<!-- <img src="<?php bloginfo("template_url")?>/images/video.png" alt=""> -->
			</div>
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-12 col-xs-12 pull-right">
						<h2>Why Choose Us?</h2>
						<p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima.</p>
						<div class="row">
							<!-- Single Choose -->
							<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.4s">
								<div class="single-choose">
									<i class="fa fa-check"></i>
									<h4>100 Awards</h4>
								</div>
							</div>
							<!-- End Single Choose -->	
							<!-- Single Choose -->
							<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.6s">
								<div class="single-choose">
									<i class="fa fa-facebook"></i>
									<h4>500K Fans</h4>
								</div>
							</div>
							<!-- End Single Choose -->	
							<!-- Single Choose -->
							<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.8s">
								<div class="single-choose">
									<i class="fa fa-youtube"></i>
									<h4>100K Subscriber</h4>
								</div>
							</div>
							<!-- End Single Choose -->	
							<!-- Single Choose -->
							<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="1s">
								<div class="single-choose">
									<i class="fa fa-support"></i>
									<h4>24/7 Support</h4>
								</div>
							</div>
							<!-- End Single Choose -->	
						</div>
					</div>					
				</div>
			</div>
		</div>	
		<!--/ End Why Choose Us -->