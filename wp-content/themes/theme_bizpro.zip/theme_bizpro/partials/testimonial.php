<!-- Start Testimonials -->
<section id="testimonial" class="section wow fadeIn">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>Our <span>Testimonials</span></h2>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="testimonial-carousel">	
							<!-- Single Testimonial -->
							<div class="single-testimonial">
								<div class="testimonial-content">
									<p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, </p>
								</div>
								<div class="testimonial-info">
									<div class="img">
										<span class="arrow"></span>
										<img src="<?php bloginfo("template_url")?>/images/testimonial1.jpg" class="img-circle" alt="">
									</div>
									<h6>Trom<span>Founder Hoadas</span></h6>
								</div>			
							</div>
							<!--/ End Single Testimonial -->
							<!-- Single Testimonial -->
							<div class="single-testimonial">
								<div class="testimonial-content">
									<p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, </p>
								</div>
								<div class="testimonial-info">
									<div class="img">
										<span class="arrow"></span>
										<img src="<?php bloginfo("template_url")?>/images/testimonial2.jpg" class="img-circle" alt="">
									</div>
									<h6>Trom<span>Founder Hoadas</span></h6>
								</div>			
							</div>
							<!--/ End Single Testimonial -->
							<!-- Single Testimonial -->
							<div class="single-testimonial">
								<div class="testimonial-content">
									<p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, </p>
								</div>
								<div class="testimonial-info">
									<div class="img">
										<span class="arrow"></span>
										<img src="<?php bloginfo("template_url")?>/images/testimonial3.jpg" class="img-circle" alt="">
									</div>
									<h6>Trom<span>Founder Hoadas</span></h6>
								</div>			
							</div>
							<!--/ End Single Testimonial -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Testimonial -->