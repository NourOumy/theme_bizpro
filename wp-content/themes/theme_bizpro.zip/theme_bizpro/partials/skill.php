<!-- Our Skill -->
<section id="our-skill" class="section">
			<div class="container">
				<div class="row"> 
					<div class="col-md-6 col-sm-12 col-xs-12 wow fadeIn">
						<!-- Info Main -->
						<div class="info-main">
							<div class="section-title left">
								<h2>Some <span>Info</span></h2>
							</div>
							<div class="some-info">
								<p>Morbi laoreet urna ante, quis luctus nisi sodales sit amet. Aliquam a enim in massa molestie mollis. Proin quis velit at nisl vulputate egestas non in arcu.Ut sodales eleifend sapien at fermentum.</p>
							</div>
							<ul class="info-list">
								<li><i class="fa fa-check"></i>consectetuer adipiscing elit, sed diam nonummy.</li>
								<li><i class="fa fa-check"></i>has been the industry'sstandar.</li>
								<li><i class="fa fa-check"></i>has been the industry'sstandar.</li>
								<li><i class="fa fa-check"></i>Pellentesque habitant morbi tristique senectus.</li>
							</ul>	
						</div>
						<!--/ End Info Main -->
					</div>				
					<div class="col-md-6 col-sm-12 col-xs-12">
						<!-- Skill Main -->
						<div class="skill-main">
							<div class="section-title left">
								<h2>Our <span>Skills</span></h2>
							</div>
							<!-- Single Skill -->
							<div class="single-skill">
								<div class="skill-info">
									<h4>Creative</h4>
								</div>
								<div class="progress">
									<div class="progress-bar" data-percent="80"><span>80%</span></div>
								</div>
							</div>	
							<!--/ End Single Skill -->
							<!-- Single Skill -->
							<div class="single-skill">
								<div class="skill-info">
									<h4>Web Design</h4>
								</div>
								<div class="progress">
									<div class="progress-bar" data-percent="90"><span>90%</span></div>
								</div>
							</div>	
							<!--/ End Single Skill -->
							<!-- Single Skill -->
							<div class="single-skill">
								<div class="skill-info">
									<h4>Marketing</h4>
								</div>
								<div class="progress">
									<div class="progress-bar" data-percent="70"><span>70%</span></div>
								</div>
							</div>	
							<!--/ End Single Skill -->
							<!-- Single Skill -->
							<div class="single-skill">
								<div class="skill-info">
									<h4>Success</h4>
								</div>
								<div class="progress">
									<div class="progress-bar" data-percent="60"><span>95%</span></div>
								</div>
							</div>	
							<!--/ End Single Skill -->
						</div>
						<!--/ End Skill Main -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End Our Skill -->