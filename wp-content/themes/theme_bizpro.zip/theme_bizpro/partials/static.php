<!-- Start Statics -->
<section id="statics" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-12 col-xs-12">
						<div class="row">
							<div class="statics">	
								<div class="col-md-12 col-sm-12 col-xs-12">
									<h2>World Domination!</h2>
									<p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima.</p>
								</div>
								<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.4s">
									<!-- Static Single -->
									<div class="static-single">
										<div class="number"><span class="counter">1300</span></div>
										<p>Project Complete</p>
									</div>
								</div>
								<!-- End Single -->	
								<!-- Static Single -->
								<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.6s">
									<div class="static-single">
										<div class="number"><span class="counter">123300</span></div>
										<p>Support Tiket</p>
									</div>
								</div>
								<!-- End Single -->	
								<!-- Static Single -->
								<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.8s">
									<div class="static-single">
										<div class="number"><span class="counter">55300</span></div>
										<p>Global Clients</p>
									</div>
								</div>
								<!-- End Single -->	
								<!-- Static Single -->
								<div class="col-md-6 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="1s">
									<div class="static-single">
										<div class="number"><span class="counter">40.99</span><span class="percent">%</span></div>
										<p>World Domination</p>
									</div>
								</div>
								<!-- End Single -->	
							</div>
						</div>
					</div>					
				</div>
			</div>
			<div class="static-image wow fadeIn"></div>
		</section>	
		<!--/ End Statics -->