<!-- Newslatter -->
<div id="newslatter" class="wow fadeIn">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-6 col-xs-12">
						<h2>Signup Newslatter</h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry'sstandard dummy text</p>
					</div>
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="newslatter">
							<form>
								<input type="email" placeholder="type your email">
								<button type="submit" class="button primary"><i class="fa fa-paper-plane"></i></button>
							</form>	
						</div>
					</div>
				</div>
			</div>
		</div>
<!--/ End Newslatter -->