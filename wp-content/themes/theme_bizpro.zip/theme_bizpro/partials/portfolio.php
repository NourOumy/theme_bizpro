<!-- Start Portfolio -->
<section id="portfolio" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>Our <span>Portfolio</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="portfolio-carousel">
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="<?php bloginfo("template_url")?>/images/portfolio/1.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="<?php bloginfo("template_url")?>/images/portfolio/1.jpg" alt=""/>
										<i class="fa fa-search"></i>
									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.html">Portfolio 1</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="<?php bloginfo("template_url")?>/images/portfolio/2.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="<?php bloginfo("template_url")?>/images/portfolio/2.jpg" alt=""/>
										<i class="fa fa-search"></i>
									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.html">Portfolio 2</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="<?php bloginfo("template_url")?>/images/portfolio/3.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="<?php bloginfo("template_url")?>/images/portfolio/3.jpg" alt=""/>
										<i class="fa fa-search"></i>
									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.html">Portfolio 3</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="<?php bloginfo("template_url")?>/images/portfolio/4.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="<?php bloginfo("template_url")?>/images/portfolio/4.jpg" alt=""/>
										<i class="fa fa-search"></i>
									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.html">Portfolio 4</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="<?php bloginfo("template_url")?>/images/portfolio/5.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="<?php bloginfo("template_url")?>/images/portfolio/5.jpg" alt=""/>
										<i class="fa fa-search"></i>
									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.html">Portfolio 5</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
							<!-- Single Portfolio -->
							<div class="portfolio-single">
								<a href="<?php bloginfo("template_url")?>/images/portfolio/6.jpg" class="zoom">
									<div class="portfolio-head">
										<img src="<?php bloginfo("template_url")?>/images/portfolio/6.jpg" alt=""/>
										<i class="fa fa-search"></i>
									</div>
								</a>
								<div class="text">
									<h4><a href="portfolio-single.html">Portfolio 6</a></h4>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam interdum.</p>
								</div>
							</div>
							<!--/ End Portfolio -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Portfolio -->