<!-- Start Clients -->
<div id="clients" class="section wow fadeIn">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="clients-carousel">
							<!-- Single Clients -->
							<div class="single-client">
								<img src="<?php bloginfo("template_url")?>/images/client1.png" alt="" class="img-responsive">
							</div>
							<!--/ Single Clients -->
							<!-- Single Clients -->
							<div class="single-client">
								<img src="<?php bloginfo("template_url")?>/images/client2.png" alt="" class="img-responsive">
							</div>
							<!--/ Single Clients -->
							<!-- Single Clients -->
							<div class="single-client">
								<img src="<?php bloginfo("template_url")?>/images/client3.png" alt="" class="img-responsive">
							</div>
							<!--/ Single Clients -->
							<!-- Single Clients -->
							<div class="single-client">
								<img src="<?php bloginfo("template_url")?>/images/client4.png" alt="" class="img-responsive">
							</div>
							<!--/ Single Clients -->
							<!-- Single Clients -->
							<div class="single-client">
								<img src="<?php bloginfo("template_url")?>/images/client5.png" alt="" class="img-responsive">
							</div>
							<!--/ Single Clients -->
							<!-- Single Clients -->
							<div class="single-client">
								<img src="<?php bloginfo("template_url")?>/images/client6.png" alt="" class="img-responsive">
							</div>		
							<!--/ Single Clients -->
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--/ End Clients -->		