<!-- Location -->
<section id="location" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>Our <span>Location</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeIn" data-wow-delay="0.4s">
						<!-- Single Address -->
						<div class="single-address">
							<i class="fa fa-phone"></i>
							<h4>Our Phone</h4>
							<p>+8801812345678, +8801700000123</p>
						</div>
						<!--/ End Single Address -->
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeIn" data-wow-delay="0.6s">
						<!-- Single Address -->
						<div class="single-address active">
							<i class="fa fa-phone"></i>
							<h4>Office Location</h4>
							<p>240, Khilgaon Dhaka 1230.</p>
						</div>
						<!--/ End Single Address -->
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 wow fadeIn" data-wow-delay="0.8s">
						<!-- Single Address -->
						<div class="single-address">
							<i class="fa fa-phone"></i>
							<h4>Corporate Email</h4>
							<p>info@Bizpro.com, support@Bizpro.com</p>
						</div>
						<!--/ End Single Address -->
					</div>
				</div>
			</div>
</section>
		<!--/ End Location -->