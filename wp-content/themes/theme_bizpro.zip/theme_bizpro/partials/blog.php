<!-- Start blog -->
<section id="blog" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12  wow fadeIn">
						<div class="section-title center">
							<h2>Our <span>Blog</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="blog">
							<div class="col-md-4 col-sm-6 col-xs-12">
								<!-- Single blog -->
								<div class="single-blog">
									<div class="blog-head">
										<img src="<?php bloginfo("template_url")?>/images/blog/1.jpg" alt="#">
										<a href="blog-single.html" class="link"><i class="fa fa-link"></i></a>
									</div>
									<div class="blog-content">
										<h2><a href="blog-single.html">We create one page business website</a></h2>
										<div class="meta">
											<span><i class="fa fa-user"></i>admin</span>
											<span><i class="fa fa-calendar"></i>19 May</span>
											<span><i class="fa fa-comments"></i>5 Comments</span>
										</div>
										<p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis.</p>
										<a href="blog-single.html" class="btn">Read More<i class="fa fa-angle-double-right"></i></a>
									</div>
								</div>	
								<!--/ End Single blog -->
							</div>
							<div class="col-md-4 col-sm-6 col-xs-12">
								<!-- Single blog -->
								<div class="single-blog">
									<div class="blog-head">
										<img src="<?php bloginfo("template_url")?>/images/blog/2.jpg" alt="#">
										<a href="blog-single.html" class="link"><i class="fa fa-link"></i></a>
									</div>
									<div class="blog-content">
										<h2><a href="blog-single.html">Super,Clean HTML5 Templates ever you seen!</a></h2>
										<div class="meta">
											<span><i class="fa fa-user"></i>admin</span>
											<span><i class="fa fa-calendar"></i>19 May</span>
											<span><i class="fa fa-comments"></i>5 Comments</span>
										</div>
										<p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis.</p>
										<a href="blog-single.html" class="btn">Read More<i class="fa fa-angle-double-right"></i></a>
									</div>
								</div>	
								<!--/ End Single blog -->
							</div>
							<div class="col-md-4 col-sm-6 col-xs-12">
								<!-- Single blog -->
								<div class="single-blog">
									<div class="blog-head">
										<img src="<?php bloginfo("template_url")?>/images/blog/3.jpg" alt="#">
										<a href="blog-single.html" class="link"><i class="fa fa-link"></i></a>
									</div>
									<div class="blog-content">
										<h2><a href="blog-single.html">Responsive Retina Ready Html template</a></h2>
										<div class="meta">
											<span><i class="fa fa-user"></i>admin</span>
											<span><i class="fa fa-calendar"></i>19 May</span>
											<span><i class="fa fa-comments"></i>5 Comments</span>
										</div>
										<p>Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis.</p>
										<a href="blog-single.html" class="btn">Read More<i class="fa fa-angle-double-right"></i></a>
									</div>
								</div>	
								<!--/ End Single blog -->
							</div>
						</div>
					</div>

                    <a href="<?php bloginfo('url') ?>/blog-archive/" class="button primary">Afficher tous les articles de blogg</a>

				</div>
			</div>
		</section>
		<!--/ End blog -->