<!-- Start About Us -->
<section id="about-us" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>About <span>US</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<div class="row"> 
					<!-- About Image -->
					<div class="col-md-5 col-sm-12 col-xs-12 wow slideInLeft">
						<div class="about-main">
							<div class="about-img">
								<img src="<?php bloginfo("template_url")?>/images/about.jpg" alt=""/>
							</div>
						</div>
					</div>
					<!--/ End About Image -->
					<div class="col-md-7 col-sm-12 col-xs-12 wow fadeIn" data-wow-delay="1s">
						<!-- About Tab -->
						<div class="tabs-main">
							<!-- Tab Nav -->
							<ul class="nav nav-tabs" role="tablist">
								<li role="presentation" class="active"><a href="#welcome"  data-toggle="tab">Welcome</a></li>
								<li role="presentation"><a href="#about" data-toggle="tab">About Us</a></li>
								<li role="presentation"><a href="#information"  data-toggle="tab">Information</a></li>
							</ul>
							<!--/ End Tab Nav -->
							<!-- Tab Content -->
							<div class="tab-content">
								<div role="tabpanel" class="tab-pane fade in active" id="welcome">
									<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
									<div class="row">
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-check"></i>
												<h4>Super Technology</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-support"></i>
												<h4>Live Support</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-send"></i>
												<h4>fast Delivery</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-rocket"></i>
												<h4>Speed Marketing</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane fade in" id="about">
									<div class="about">
										<p>Aliquam erat volutpat. Phasellus lobortis erat vitae fringilla malesuada. Fusce semper purus suscipit ultricies tincidunt. Nulla eget turpis ac leo euismod pharetra at nec diam. Etiam id purus lacus. Suspendisse ligula nulla, cursus non lacinia tincidunt, elementum eu sapien</p>
										<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
										<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
									</div>
								</div>
								<div role="tabpanel" class="tab-pane fade in" id="information">
									<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
									<div class="row">
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-check"></i>
												<h4>Super Technology</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-support"></i>
												<h4>Live Support</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-send"></i>
												<h4>fast Delivery</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
										<div class="col-md-6 col-sm-6 col-xs-12">
											<!-- Single Tab -->
											<div class="single-tab">
												<i class="fa fa-rocket"></i>
												<h4>Speed Marketing</h4>
												<p>It has roots in a piece of classical Latin literature from 45 BC[..]</p>
											</div>
											<!--/ End Single Tab -->
										</div>
									</div>
								</div>
							</div>
							<!--/ End Tab Content -->
						</div>
						<!--/ End About Tab -->
					</div>
				</div>
			</div>
		</section>
		<!--/ End About Us -->