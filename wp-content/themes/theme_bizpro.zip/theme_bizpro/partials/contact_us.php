<!-- Contact Us -->
<section id="contact" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>Contact <span>US</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<!-- Google Map -->
				<div class="row">
					<!-- Contact Form -->
					<div class="col-md-5 col-sm-5 col-xs-12">
						<form class="form" method="post" action="mail/mail.php">
							<div class="form-group">
								<input type="text" name="name" placeholder="Name" required="required">
                            </div>
							<div class="form-group">
								<input type="email" name="email" placeholder="Email" required="required">
                            </div>
							<div class="form-group">
								<input type="text" name="subject" placeholder="Subject" required="required">
                            </div>
							<div class="form-group">
								<textarea name="message" rows="6" placeholder="Message" ></textarea>
                            </div>
							<div class="form-group">	
								<button type="submit" class="button primary"><i class="fa fa-send"></i>Submit</button>
                            </div>
						</form>
					</div>
					<!--/ End Contact Form -->
				</div>
			</div>
			<div class="gmap">
				<div class="map"></div>
			</div>
		</section>
		<!--/ End Clients Us -->