<!-- Start Team -->
<section id="team" class="section">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeIn">
						<div class="section-title center">
							<h2>Lovely <span>Team</span></h2>
							<p>Coordinates for abs potioning the closest positioned parent box of the positioned abs qoning the closes for abs potioning the closest positioned parent.</p>
						</div>
					</div>
				</div>
				<div class="row">	
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.4s">
						<!-- Single Team -->
						<div class="single-team">
							<div class="team-head">
								<img src="<?php bloginfo("template_url")?>/images/team/team1.jpg" alt=""/>
							</div>
							<div class="team-info">
								<div class="name">
									<h4>Trans L<span>Creative Director</span></h4>
								</div>
								<p>Pellentesque habitant morbi tristique senectus et netus et malesuada</p>
								<ul class="team-social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-instagram"></i></a></li>
								</ul>
							</div>
						</div>
						<!--/ End Single Team -->
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.6s">	
						<!-- Single Team -->
						<div class="single-team">
							<div class="team-head">
								<img src="<?php bloginfo("template_url")?>/images/team/team2.jpg" alt=""/>
							</div>
							<div class="team-info">
								<div class="name">
									<h4>Augsed Lamp<span>Web Developer</span></h4>
								</div>
								<p>Pellentesque habitant morbi tristique senectus et netus et malesuada</p>
								<ul class="team-social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-instagram"></i></a></li>
								</ul>
							</div>
						</div>
						<!--/ End Single Team -->
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="0.8s">
						<!-- Single Team -->
						<div class="single-team active">
							<div class="team-head">
								<img src="<?php bloginfo("template_url")?>/images/team/team3.jpg" alt=""/>
							</div>
							<div class="team-info">
								<div class="name">
									<h4>Fronas Kie<span>Server Administor</span></h4>
								</div>
								<p>Pellentesque habitant morbi tristique senectus et netus et malesuada</p>
								<ul class="team-social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-instagram"></i></a></li>
								</ul>
							</div>
						</div>
						<!--/ End Single Team -->
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12 wow fadeIn" data-wow-delay="1s">	
						<!-- Single Team -->
						<div class="single-team">
							<div class="team-head">
								<img src="<?php bloginfo("template_url")?>/images/team/team4.jpg" alt=""/>
							</div>
							<div class="team-info">
								<div class="name">
									<h4>Lifae Hoadas<span>UI/UX Design</span></h4>
								</div>
								<p>Pellentesque habitant morbi tristique senectus et netus et malesuada</p>
								<ul class="team-social">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-instagram"></i></a></li>
								</ul>
							</div>
						</div>
						<!--/ End Single Team -->
					</div>
				</div>
            </div>
		</section>	 
		<!--/ End Team -->		